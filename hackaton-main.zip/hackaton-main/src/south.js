const souths=[{
    "name": "SOUTH INDIAN THALI",
    "varients": [
        "mini",
        "full"
    ],
    "prices": [{
        "mini": 150,
        "full": 250
    },],
    "category": "non-veg",
    "image": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSvBWkLnMjVw_bXfEG52zyW_a-fsiJuKy-1zw&usqp=CAU",
    "description": "Variety of dishes served on large platter"
}, {
    "name": "SOUTH INDIAN THALI",
    "varients": [
        "mini",
        "full"
    ],
    "prices": [{
        "mini": 200,
        "full": 400
    },],
    "category": "veg",
    "image": "https://imgk.timesnownews.com/story/veg-thali.gif",
    "description": ""

},{
    "name": "NORTH INDIAN THALI",
    "varients": [
        "mini",
        "full"
    ],
    "prices": [{
        "mini": 250,
        "full": 450
    },],
    "category": "non-veg",
    "image": "https://tse1.mm.bing.net/th?id=OIP.nGvkXV2bEi5Ba-c8Ny0gRQHaFj&pid=Api&P=0&h=180",
    "description": ""
},
{
"name": "NORTH INDIAN THALI",
"varients": [
    "mini",
    "full"
],
"prices": [{
    "mini": 150,
    "full": 250
},],
"category": "veg",
"image": "https://tse1.mm.bing.net/th?id=OIP.Ab1yfmkQZWRUNzhLtIgmbQHaF7&pid=Api&P=0&h=180",
"description": ""

},
{
    "name": "EAST INDIAN THALI",
    "varients": [
        "mini",
        "full"
    ],
    "prices": [{
        "mini": 250,
        "full": 550
    },],
    "category": "non-veg",
    "image": "https://i.pinimg.com/564x/91/ac/e3/91ace37428dda2233a74492c5c090596.jpg",
    "description": "Variety of dishes served on large platter"
},
{
    "name": "EAST INDIAN THALI",
    "varients": [
        "mini",
        "full"
    ],
    "prices": [{
        "mini": 250,
        "full": 450
    },],
    "category": "veg",
    "image": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS-KPXDPeL4ylDwSNZX-NuP78INPr9PcZlRYw&usqp=CAU",
    "description": "Variety of dishes served on large platter"
},
];
export default souths








